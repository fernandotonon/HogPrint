/*
 * Project name:
     Flash_Test (Demonstration of writing to PIC's internal flash memory)
 * Copyright:
     (c) MikroElektronika, 2005-2008.
 * Description:
     This is a simple demonstration how to use to PIC's internal flash memory to
     store data. The data is being written starting from the given location;
     then, the same locations are read and the data is displayed on PORTB.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on LEDs on PORTB SW10.2. (board specific)
*/
 
char i;
long addr;
unsigned short dataRd;
unsigned short dataWr[64];

void main() {
  ADCON1 |= 0x0F;                // Configure AN pins as digital
  CMCON  |= 7;                   // Disable comparators

  LATB = 0;
  TRISB = 0;

  for (i=0; i<64; i++)
    dataWr[i] = i+1;

  addr = 0x800;                  // valid for P18F8520
  FLASH_Erase_1024(addr);
  FLASH_Write_64(addr, dataWr);

  for (i = 0; i < 64; i++) {
    dataRd = FLASH_Read(addr++);
    LATB = dataRd;
    Delay_ms(200);
  }
}
