/*
 * Project name:
     UART2 (Simple usage of UART module library functions)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This code demonstrates how to use UART library routines. Upon receiving
     data via RS232, MCU immediately sends it back to the sender.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:UART2
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - RS232 RX and TX switches SW12.5 and SW12.6 should be turned On (board specific).
*/

char uart_rd;

void main() {
  ADCON1 |= 0x0F;                // Configure AN pins as digital
  CMCON  |= 7;                   // Disable comparators
  
  UART2_Init(19200);             // Initialize UART2 module at 9600 bps
  UART2_Write_Text("Start");
  UART2_Write(13);
  UART2_Write(10);
  
  Delay_ms(100);                 // Wait for UART2 module to stabilize

  while (1) {                    // Endless loop
    if (UART2_Data_Ready()) {    // If data is received,
      uart_rd = UART2_Read();    //   read the received data,
      UART2_Write(uart_rd);      //   and send data via UART2
    }
  }
}