/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     PORTA, PORTB, PORTC, PORTD, PORTE, PORTF, PORTG and PORTH.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:LEDs
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn ON the PORTA, PORTB, PORTC LEDs at SW10. (board specific)
*/

void main() {
  ADCON1 |= 0x0F;        // Configure AN pins as digital
  CMCON  |= 7;           // Disable comparators
  
  TRISA = 0x00;          // set direction to be output
  TRISB = 0x00;          // set direction to be output
  TRISC = 0x00;          // set direction to be output
  TRISD = 0x00;          // set direction to be output
  TRISE = 0x00;          // set direction to be output
  TRISF = 0x00;          // set direction to be output
  TRISG = 0x00;          // set direction to be output
  TRISH = 0x00;          // set direction to be output
  TRISJ = 0x00;          // set direction to be output
  
  do {
    PORTA = 0x00;        // Turn OFF LEDs on PORTA
    PORTB = 0x00;        // Turn OFF LEDs on PORTB
    PORTC = 0x00;        // Turn OFF LEDs on PORTC
    PORTD = 0x00;        // Turn OFF LEDs on PORTD
    PORTE = 0x00;        // Turn OFF LEDs on PORTE
    PORTF = 0x00;        // Turn OFF LEDs on PORTF
    PORTG = 0x00;        // Turn OFF LEDs on PORTG
    PORTH = 0x00;        // Turn OFF LEDs on PORTH
    PORTJ = 0x00;        // Turn OFF LEDs on PORTJ
    Delay_ms(1000);      // 1 second delay

    
    PORTA = 0xFF;        // Turn ON LEDs on PORTA
    PORTB = 0xFF;        // Turn ON LEDs on PORTB
    PORTC = 0xFF;        // Turn ON LEDs on PORTC
    PORTD = 0xFF;        // Turn ON LEDs on PORTD
    PORTE = 0xFF;        // Turn ON LEDs on PORTE
    PORTF = 0xFF;        // Turn ON LEDs on PORTF
    PORTG = 0xFF;        // Turn ON LEDs on PORTG
    PORTH = 0xFF;        // Turn ON LEDs on PORTH
    PORTJ = 0xFF;        // Turn ON LEDs on PORTJ

    Delay_ms(1000);      // 1 second delay
  } while(1);            // Endless loop
}