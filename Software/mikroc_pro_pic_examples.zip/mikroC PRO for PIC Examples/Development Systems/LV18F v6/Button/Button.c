/*
 * Project name:
     Button (Demonstration of using Button Library)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20080110:
       - initial release;
 * Description:
     This program demonstrates usage on-board button as PORTB input.
     On every RB0 one-to-zero transition PORTC is inverted.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:Buttons
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn ON the PORTC LEDs.
     - Put button jumper (J12) into VCC position and pull-down PORTB. (board specific)
*/

bit oldstate;                       // Old state flag

void main() {

  ADCON1 |= 0x0F;                   // Configure AN pins as digital
  CMCON  |= 7;                      // Disable comparators

  TRISB0_bit = 1;                   // Set pin as input

  TRISC = 0x00;                     // Configure PORTC as output
  PORTC = 0xAA;                     // Initial PORTC value
  oldstate = 0;

  do {
    if (Button(&PORTB, 0, 1, 1)) {  // Detect logical one
      oldstate = 1;                 // Update flag
    }
    if (oldstate && Button(&PORTB, 0, 1, 0)) { // Detect one-to-zero transition
      PORTC = ~PORTC;               // Invert PORTC
      oldstate = 0;                 // Update flag
    }
  } while(1);                       // Endless loop
}