/*
 * Project name:
     OneWire (Interfacing the DS1820 temperature sensor - all versions)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20080930:
       - initial release;
 * Description:
     This code demonstrates one-wire communication with temperature sensor
     DS18x20 connected to RD0 or RA5 pin.
     MCU reads temperature from the sensor and prints it on the LCD.
     The display format of the temperature is 'xxx.xxxx�C'. To obtain correct
     results, the 18x20's temperature resolution has to be adjusted (constant
     TEMP_RESOLUTION).
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:OneWire
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    DS18x20, LCD 2x16
                      http://www.mikroe.com/eng/categories/view/43/components/
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Place DS1820 jumper (J11) in upper position to use RD0 as OW pin (board specific).
     - Turn on LCD backlight switch SW12.7 (board specific).
     - Pull up (place jumper J4 in upper position)  (board specific)
       and turning off LEDs on PORTD (SW10.4)  (board specific)
       used for one wire bus may be required.
*/

// LCD module connections
sbit LCD_RS at LATB0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_EN at LATB1_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D4 at LATB2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D5 at LATB3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D6 at LATB4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D7 at LATB5_bit;  // for writing to output pin always use latch (PIC18 family)

sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;
// End LCD module connections

//  Set TEMP_RESOLUTION to the corresponding resolution of used DS18x20 sensor:
//  18S20: 9  (default setting; can be 9,10,11,or 12)
//  18B20: 12
const unsigned short TEMP_RESOLUTION = 9;

char *text = "000.0000";
unsigned temp;

void Display_Temperature(unsigned int temp2write) {
  const unsigned short RES_SHIFT = TEMP_RESOLUTION - 8;
  char temp_whole;
  unsigned int temp_fraction;

  // check if temperature is negative
  if (temp2write & 0x8000) {
     text[0] = '-';
     temp2write = ~temp2write + 1;
     }

  // extract temp_whole
  temp_whole = temp2write >> RES_SHIFT ;

  // convert temp_whole to characters
  if (temp_whole/100)
     text[0] = temp_whole/100  + 48;
  else
     text[0] = '0';

  text[1] = (temp_whole/10)%10 + 48;             // Extract tens digit
  text[2] =  temp_whole%10     + 48;             // Extract ones digit

  // extract temp_fraction and convert it to unsigned int
  temp_fraction  = temp2write << (4-RES_SHIFT);
  temp_fraction &= 0x000F;
  temp_fraction *= 625;

  // convert temp_fraction to characters
  text[4] =  temp_fraction/1000    + 48;         // Extract thousands digit
  text[5] = (temp_fraction/100)%10 + 48;         // Extract hundreds digit
  text[6] = (temp_fraction/10)%10  + 48;         // Extract tens digit
  text[7] =  temp_fraction%10      + 48;         // Extract ones digit

  // print temperature on LCD
  Lcd_Out(2, 5, text);
}

void main() {
  ADCON1 |= 0x0F;                    // Configure AN pins as digital
  CMCON  |= 7;                       // Disable comparators

  Lcd_Init();                        // Initialize LCD
  Lcd_Cmd(_LCD_CLEAR);               // Clear LCD
  Lcd_Cmd(_LCD_CURSOR_OFF);          // Turn cursor off
  Lcd_Out(1, 1, " Temperature:   ");
  // Print degree character, 'C' for Centigrades
  Lcd_Chr(2,13,178);  // different LCD displays have different char code for degree
                      // if you see greek alpha letter try typing 178 instead of 223

  Lcd_Chr(2,14,'C');

  //--- main loop
  do {
    //--- perform temperature reading
    Ow_Reset(&PORTD, 0);                         // Onewire reset signal
    Ow_Write(&PORTD, 0, 0xCC);                   // Issue command SKIP_ROM
    Ow_Write(&PORTD, 0, 0x44);                   // Issue command CONVERT_T
    Delay_us(120);

    Ow_Reset(&PORTD, 0);
    Ow_Write(&PORTD, 0, 0xCC);                   // Issue command SKIP_ROM
    Ow_Write(&PORTD, 0, 0xBE);                   // Issue command READ_SCRATCHPAD

    temp =  Ow_Read(&PORTD, 0);
    temp = (Ow_Read(&PORTD, 0) << 8) + temp;

    //--- Format and display result on Lcd
    Display_Temperature(temp);

    Delay_ms(500);
  } while (1);
}