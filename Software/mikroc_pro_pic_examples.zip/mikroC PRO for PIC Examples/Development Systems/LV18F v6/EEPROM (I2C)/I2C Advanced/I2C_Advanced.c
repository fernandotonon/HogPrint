/*
 * Project name:
     I2C_Advanced (Advanced I2C Example)
 * Copyright:
     (c) MikroElektronika, 2005-2010.
 * Revision History:
     20091120:
       - initial release;     
 * Description:
     This example features the advanced communication with the 24AA01 EEPROM chip
     by introducing its own library of functions for this task: init, single
     write, single and sequential read. It performs write of a sequence of bytes
     (characters) into the EEPROM and writes this out at the first row on Lcd.
     Then, data read from EEPROM is performed and the result is displayed at the
     second row on Lcd.
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:Serial_EEPROM
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    on-board Serial EEPROM module
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on EEPROM switches SW13.1 and SW13.3.
     - Turn off PORTC LEDs (SW10.3). (board specific)
     - Turn on LCD back light switch SW12.7
*/

#include "EEPROM_24AA01.h"

// LCD module connections
sbit LCD_RS at LATB0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_EN at LATB1_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D4 at LATB2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D5 at LATB3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D6 at LATB4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit LCD_D7 at LATB5_bit;  // for writing to output pin always use latch (PIC18 family)

sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;
// End LCD module connections

char someData[] = "I2C mikroE";
char i ,tmpdata;

//  Main
void main() {

  EEPROM_24AA01_Init();                      // performs I2C initialization
  ADCON1 |= 0x0F;                            // Configure AN pins as digital
  CMCON  |= 7;                               // Disable comparators
  Lcd_Init();                                // performs Lcd initialization
  Lcd_Cmd(_LCD_CLEAR);                       // clear Lcd
  Lcd_Cmd(_LCD_CURSOR_OFF);                  // set cursor off

  // Example for single-byte write
  i = 0;
  tmpdata = 1;
  while ((tmpdata = someData[i]) != 0) {
    i++;
    EEPROM_24AA01_WrSingle(i, tmpdata);      // writes data, char by char, in the EEPROM
    Delay_ms(20);
    Lcd_Chr(1,i, tmpdata);                   // diplays data on the first row of the Lcd
  }
  EEPROM_24AA01_WrSingle(i+1, 0);            // writes string termination
  Delay_ms(20);

  // Example for single-byte read
  i = 1;
  tmpdata = 1;
  while ((tmpdata = EEPROM_24AA01_RdSingle(i)) != 0) {
    Lcd_Chr(2,i, tmpdata);                  // displays data from EEPROM on the second row of the Lcd
    Delay_ms(20);
    i++ ;
  }
  
  //  Example for sequential data read
//  Delay_ms(1000);
//  Lcd_Cmd(_LCD_CLEAR);
//  EEPROM_24AA01_RdSeq(1, someData, 13);
//  Lcd_Out(2,1,someData);
}