/*
 * Project name:
     SerialRAM
 * Copyright:
     (c) MikroElektronika, 2005-2010.
 * Revision History:
     20091115:
       - initial release;
 * Description:
     Many embedded systems needs some amount of volatile storage for temporary
     data. Serial SRAMs are popular choice for volatile storage because of their
     small footprint, low I/O pin requirement, low-power consumption and low cost.
     This example writes and reads data from 23K640 Serial RAM device in byte
     read/write operation mode using standard SPI communication. For more
     information about available operating modes consult 23K640 datasheet:
     http://ww1.microchip.com/downloads/en/DeviceDoc/22126C.pdf
 * Test configuration:
     MCU:             PIC18F87J60
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39762d.pdf
     Dev.Board:       LV18F v6 - ac:Serial_RAM
                      http://www.mikroe.com/eng/products/view/303/lv18f-v6-development-system/
     Oscillator:      HS, 25.0000 MHz
     Ext. Modules:    on-board serial RAM module
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on SPI lines SW11.1, SW11.3, SW11.5 and turn on switches SW11.7, SW11.8
     - Turn off PORTC LEDs at SW10.3 (board specific)
     - Turn on PORTB LEDs at SW10.2 (board specific)
*/

// Serial RAM connections
sbit Chip_Select at LATC0_bit;
sbit HOLD at LATC1_bit;
sbit Chip_Select_Direction at TRISC0_bit;
sbit HOLD_Direction at TRISC1_bit;
// End serial RAM connections

unsigned int i;
unsigned short tmp;

// Write one byte of data to specified address
void Write_Data(unsigned int address, unsigned short dat){
  Chip_Select = 0;                       // Select serial RAM
  SPI1_Write(2);                         // Write instruction
  SPI1_Write(address >> 8);              // Sending 16 bits address
  SPI1_Write(address);
  SPI1_Write(dat);                       // Writing one byte of data
  Chip_Select = 1;                       // Deselect serial RAM
 }

// Read one byte of data from specified address
unsigned short Read_Data(unsigned int address){
  char buffer;
  Chip_Select = 0;                       // Select serial RAM
  SPI1_Write(3);                         // Read instruction
  SPI1_Write(address >> 8);              // Sending 16 bits address
  SPI1_Write(address);
  tmp = SPI1_Read(buffer);               // Read one byte of data
  Chip_Select = 1;                       // Deselect serial RAM
  return tmp;
}

void main() {
  ADCON1 |= 0x0F;                        // Configure AN pins as digital
  CMCON  |= 7;                           // Disable comparators

  TRISB  = 0;                            // PORTB is output
  LATB  = 0;

  Chip_Select_Direction = 0;             // Set CS# pin as Output
  Chip_Select = 1;                       // Deselect serial RAM
  SPI1_Init();                           // Initialize SPI module

  HOLD_Direction = 0;                    // Set HOLD# pin as output
  HOLD = 1;                              // Hold high when this function is not used

  for (i = 0; i < 256 ; i++){            // Write 256 bytes of data starting from address 0x0A00
    Write_Data(i+0x0A00, i);             // Write data to specified address
    LATB = Read_Data(i+0x0A00);          // Read data and display it on PORTB
    delay_ms(100);
  }
}