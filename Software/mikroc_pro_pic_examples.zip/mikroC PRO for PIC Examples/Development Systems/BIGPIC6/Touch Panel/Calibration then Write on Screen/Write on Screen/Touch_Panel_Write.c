/*
 * Project name:
     TouchPanelWrite (Demo for working with TouchPanel Controller)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20100203:
       - initial release;
 * Description:
     This code works with TouchPanel and GLCD. Two digital output and
     two analog input signals are used for communication with TouchPanel. 
     This example is for writing on the screen, calibration constants for touch
     panel are set via library function.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC6 - ac:Touch_Panel
                      http://www.mikroe.com/eng/products/view/300/bigpic6-development-system/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    GLCD 128x64, Touch Panel
                      http://www.mikroe.com/eng/products/view/277/various-components/
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * Notes:
     - Turn on GLCD backlight(SW13.8) and TouchPanel Contoller switches (SW13.1, SW13.2, SW13.3, SW13.4)(board specific).
     - Turn off LEDs connected to ADC pins.
*/

// Glcd module connections
char GLCD_DataPort at PORTD;
sbit GLCD_CS1 at LATJ0_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_CS2 at LATJ1_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RS  at LATJ2_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RW  at LATJ3_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_EN  at LATJ4_bit;  // for writing to output pin always use latch (PIC18 family)
sbit GLCD_RST at LATJ5_bit;  // for writing to output pin always use latch (PIC18 family)

sbit GLCD_CS1_Direction at TRISJ0_bit;
sbit GLCD_CS2_Direction at TRISJ1_bit;
sbit GLCD_RS_Direction  at TRISJ2_bit;
sbit GLCD_RW_Direction  at TRISJ3_bit;
sbit GLCD_EN_Direction  at TRISJ4_bit;
sbit GLCD_RST_Direction at TRISJ5_bit;
// End Glcd module connections

// Touch Panel module connections
sbit DriveA at LATJ6_bit;
sbit DriveB at LATJ7_bit;
sbit DriveA_Direction at TRISJ6_bit;
sbit DriveB_Direction at TRISJ7_bit;
// End Touch Panel module connections

bit          write_erase;
char         pen_size;
char write_msg[] = "WRITE";                                // GLCD menu messages
char clear_msg[] = "CLEAR";
char erase_msg[] = "ERASE";
unsigned int x_coord, y_coord;

void Initialize() {
  CMCON  |= 0x07;                                          // Turn off comparators
  ADCON1 |= 0x0D;                                          // Set AN0 and AN1 channel pins as analog

  Glcd_Init();                                             // Initialize GLCD
  Glcd_Fill(0);                                            // Clear GLCD

  ADC_Init();                                              // Initialize ADC
  TP_Init(128, 64, 0, 1);                                  // Initialize touch panel
  TP_Set_ADC_Threshold(900);                               // Set touch panel ADC threshold
}

void main() {

  Initialize();
  
  // You can get calibration constants using touch panel calibration example
  TP_Set_Calibration_Consts(53, 902, 121, 859);           // Set calibration constants

  Glcd_Write_Text("WRITE ON SCREEN", 20, 5, 1) ;
  Delay_ms(1000);

  Glcd_Fill(0);                                            // Clear GLCD
  Glcd_V_Line(0,7,0,1);
  Glcd_Write_Text(clear_msg,1,0,0);
  Glcd_V_Line(0,7,97,1);
  Glcd_Write_Text(erase_msg,98,0,0);

  // Pen Menu:
  Glcd_Rectangle(41,0,52,9,1);
  Glcd_Box(45,3,48,6,1);
  Glcd_Rectangle(63,0,70,7,1);
  Glcd_Box(66,3,67,4,1);
  Glcd_Rectangle(80,0,86,6,1);
  Glcd_Dot(83,3,1);

  write_erase = 1;
  pen_size = 1;
  while (1) {

    if (TP_Press_Detect()) {
      // After a PRESS is detected read X-Y and convert it to 128x64 space
      if (TP_Get_Coordinates(&x_coord, &y_coord) == 0) {

        if ((x_coord < 31) && (y_coord < 8)) {

          Glcd_Fill(0);

          // Pen Menu:
          Glcd_Rectangle(41,0,52,9,1);
          Glcd_Box(45,3,48,6,1);
          Glcd_Rectangle(63,0,70,7,1);
          Glcd_Box(66,3,67,4,1);
          Glcd_Rectangle(80,0,86,6,1);
          Glcd_Dot(83,3,1);

          Glcd_V_Line(0,7,0,1);
          Glcd_Write_Text(clear_msg,1,0,0);
          Glcd_V_Line(0,7,97,1);
          if (write_erase)
            Glcd_Write_Text(erase_msg,98,0,0);
          else
            Glcd_Write_Text(write_msg,98,0,0);
          }

        // If write/erase is pressed
        if ((x_coord > 96) && (y_coord < 8)) {
          if (write_erase) {
            write_erase = 0;
            Glcd_Write_Text(write_msg,98,0,0);
            Delay_ms(500);
            }
          else {
            write_erase = 1;
            Glcd_Write_Text(erase_msg,98,0,0);
            Delay_ms(500);
            }
          }

        // If pen size is selected
        if ((x_coord >= 41) && (x_coord <= 52) && (y_coord <= 9))
          pen_size = 3;

        if ((x_coord >= 63) && (x_coord <= 70) && (y_coord <= 7))
          pen_size = 2;

        if ((x_coord >= 80) && (x_coord <= 86) && (y_coord <= 6))
          pen_size = 1;

        if (y_coord < 11)
          continue;

        switch (pen_size) {
          case 1 : {
                     if ( (x_coord >= 0) && (y_coord >= 0) && (x_coord <= 127) && (y_coord <= 63) )
                       Glcd_Dot(x_coord, y_coord, write_erase);
                     break;
                   }
          case 2 : {
                     if ( (x_coord >= 0) && (y_coord >= 0) && (x_coord <= 127-1) && (y_coord <= 63-1) )
                       Glcd_Box(x_coord, y_coord, x_coord + 1, y_coord + 1, write_erase);
                     break;
                   }
          case 3 : {
                     if ( (x_coord >= 1) && (y_coord >= 1) && (x_coord <= 127-2) && (y_coord <= 63-2) )
                       Glcd_Box(x_coord-1, y_coord-1, x_coord + 2, y_coord + 2, write_erase);
                     break;
                   }
        }
      }
    }
  }
}