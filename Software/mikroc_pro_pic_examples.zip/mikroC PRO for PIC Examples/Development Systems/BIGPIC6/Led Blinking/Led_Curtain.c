/*
 * Project name:
     LED_Blinking (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     PORTB, PORTC and PORTD.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC6 - ac:LEDs
                      http://www.mikroe.com/eng/products/view/300/bigpic6-development-system/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn ON the PORT LEDs at SW10. (board specific)
*/
char counter;

void wait() {
  Delay_ms(100);
}

void main() {

  ADCON1 |= 0x0F;      // Configure AN pins as digital
  CMCON  |= 7;         // Disable comparators

  TRISA = 0x00;        // set direction to be output
  TRISB = 0x00;        // set direction to be output
  TRISC = 0x00;        // set direction to be output
  TRISD = 0x00;        // set direction to be output
  TRISE = 0x00;        // set direction to be output
  TRISF = 0x00;        // set direction to be output
  TRISG = 0x00;        // set direction to be output
  TRISH = 0x00;        // set direction to be output
  TRISJ = 0x00;        // set direction to be output
  
  PORTA = 0x00;        // turn OFF the PORTA leds
  PORTB = 0x00;        // turn OFF the PORTB leds
  PORTC = 0x00;        // turn OFF the PORTC leds
  PORTD = 0x00;        // turn OFF the PORTD leds
  PORTE = 0x00;        // turn OFF the PORTE leds
  PORTF = 0x00;        // turn OFF the PORTF leds
  PORTG = 0x00;        // turn OFF the PORTG leds
  PORTH = 0x00;        // turn OFF the PORTH leds
  PORTJ = 0x00;        // turn OFF the PORTJ leds
  
  while (1) {
    for (counter=0; counter<8; counter++){
      PORTA |= 1 << counter;
      PORTB |= 1 << counter;
      PORTC |= 1 << counter;
      PORTD |= 1 << counter;
      PORTE |= 1 << counter;
      PORTF |= 1 << counter;
      PORTG |= 1 << counter;
      PORTH |= 1 << counter;
      PORTJ |= 1 << counter;
      
      wait();
    }
       
    counter = 0;
    while (counter<8) {
      PORTA &= ~(1 << counter);
      PORTB &= ~(1 << counter);
      PORTC &= ~(1 << counter);
      PORTD &= ~(1 << counter);
      PORTE &= ~(1 << counter);
      PORTF &= ~(1 << counter);
      PORTG &= ~(1 << counter);
      PORTH &= ~(1 << counter);
      PORTJ &= ~(1 << counter);
      
      wait();
      counter++;
    }
  }
}