/*
 * Project name:
     ADC_on_LEDs (Display the result of ADC on LEDs)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20081218:
       - initial release;
 * Description:
      A simple example of using the ADC library.
      ADC results are displayed on PORTC and PORTD.
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC6 - ac:ADC
                      http://www.mikroe.com/eng/products/view/300/bigpic6-development-system/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on PORTC and PORTD LEDs.
     - To simulate analog input on ADC channel 2, use on-board potentiometer P3
       by connecting jumper J11 (board specific) to MCU pin corresponding to ADC channel 2 input.
 */

#include <built_in.h>
unsigned int adc_rd;

void main() {

  CMCON  |= 0x07;            // turn off comparators
  ADCON1 |= 0x0C;            // Set AN2 channel pin as analog
  TRISA2_bit = 1;            //   input

  TRISC = 0x00;              // Set PORTC as output
  TRISD = 0x00;              // Set PORTD as output
  
  while (1) {
    adc_rd = ADC_Read(2);    // get ADC value from 2nd channel
    PORTC = adc_rd;          // display adc_rd[7..0]
    PORTD = Hi(adc_rd);      // display adc_rd[9..8]
  }
}