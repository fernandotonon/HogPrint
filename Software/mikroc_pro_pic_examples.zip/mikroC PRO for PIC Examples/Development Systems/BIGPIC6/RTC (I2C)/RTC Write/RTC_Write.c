/*
 * Project name:
     RTC_Write (Demonstration on working with the RTC Module and I2C routines)
 * Copyright:
     (c) mikroElektronika, 2005-2010.
 * Revision History:
     20081218:
       - initial release;
 * Description:
     This project is simple demonstration how to set date and time on DS1307
     RTC (real-time clock).
 * Test configuration:
     MCU:             P18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC6 -  ac:RTC
                      http://www.mikroe.com/eng/products/view/300/bigpic6-development-system/
     Oscillator:      HS, 10.0 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - I2C communication lines PORTC should be connected (jumper J3)
       to pull-up resistors (board specific) and turn on RTC I2C swtiches on
       the board SW13.5 and SW13.6 (board specific)
     - Turn off PORTC LEDs SW10 connected to I2C communication lines.(board specific)
 */

void main() {

  ADCON1 |= 0x0F;           // Configure AN pins as digital
  CMCON  |= 7;              // Disable comparators

  Delay_ms(1000);

   I2C1_Init(100000);     // initialize full master mode
   I2C1_Start();          // issue start signal
   I2C1_Wr(0xD0);         // address DS1307
   I2C1_Wr(0);            // start from word at address (REG0)
   I2C1_Wr(0x80);         // write $80 to REG0. (pause counter + 0 sec)
   I2C1_Wr(0);            // write 0 to minutes word to (REG1)
   I2C1_Wr(0x17);         // write 17 to hours word (24-hours mode)(REG2)
   I2C1_Wr(0x02);         // write 2 - Monday (REG3)
   I2C1_Wr(0x04);         // write 4 to date word (REG4)
   I2C1_Wr(0x05);         // write 5 (May) to month word (REG5)
   I2C1_Wr(0x09);         // write 09 to year word (REG6)
   I2C1_Stop();           // issue stop signal

   I2C1_Start();          // issue start signal
   I2C1_Wr(0xD0);         // address DS1307
   I2C1_Wr(0);            // start from word at address 0
   I2C1_Wr(0);            // write 0 to REG0 (enable counting + 0 sec)
   I2C1_Stop();           // issue stop signal
}