/*
 * Project name:
     PortExpander (Demonstration of the Port Expander library routines)
 * Copyright:
     (c) Mikroelektronika, 2005-2010.
 * Revision History:
     20090505:
       - initial release;
 * Description:
     This project is simple demonstration how to use Port Expander Library functions.
 * Test configuration:
     MCU:             PIC18F8520
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39609b.pdf
     Dev.Board:       BIGPIC6 - ac:PortExpander
                      http://www.mikroe.com/eng/products/view/300/bigpic6-development-system/
     Oscillator:      HS, 10.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on Port Expander switches SW11.1 SW11.2 SW11.3 SW11.4 and SW11.5 (board specific).
     - Turn on PORTB LEDs SW11.6 (board specific).
 */

// Port Expander module connections
sbit  SPExpanderCS  at LATE0_bit;
sbit  SPExpanderRST at LATE1_bit;
sbit  SPExpanderCS_Direction  at TRISE0_bit;
sbit  SPExpanderRST_Direction at TRISE1_bit;
// End Port Expander module connections

unsigned char i = 0;

// comment / uncomment the apropriate line to
// get output on the wanted port PO or P1

#define Output_PORT0
//#define Output_PORT1

void main() {

  ADCON1 |= 0x0F;                    // Configure AN pins as digital
  CMCON  |= 7;                       // Disable comparators
  TRISB = 0x00;
  #ifdef Output_PORT0
  // Port Expander Library uses SPI1 module
  SPI1_Init();                           // Initialize SPI module used with PortExpander

  Expander_Init(0);                      // Initialize Port Expander

  Expander_Set_DirectionPortA(0, 0x00);  // Set Expander's PORTA to be output

  Expander_Set_DirectionPortB(0,0xFF);   // Set Expander's PORTB to be input
  Expander_Set_PullUpsPortB(0,0xFF);     // Set pull-ups to all of the Expander's PORTB pins

  while(1) {                             // Endless loop
    Expander_Write_PortA(0, i++);        // Write i to expander's PORTA
    LATB = Expander_Read_PortB(0);      // Read expander's PORTB and write it to LEDs
    Delay_ms(100);
  }
  #endif

  #ifdef Output_PORT1
    // Port Expander Library uses SPI1 module
  SPI1_Init();                           // Initialize SPI module used with PortExpander

  Expander_Init(0);                      // Initialize Port Expander

  Expander_Set_DirectionPortB(0, 0x00);  // Set Expander's PORTA to be output

  Expander_Set_DirectionPortA(0,0xFF);   // Set Expander's PORTB to be input
  Expander_Set_PullUpsPortA(0,0xFF);     // Set pull-ups to all of the Expander's PORTB pins

  while(1) {                             // Endless loop
    Expander_Write_PortB(0, i++);        // Write i to expander's PORTA
    LATB = Expander_Read_PortA(0);      // Read expander's PORTB and write it to LEDs
    Delay_ms(100);
  }
  #endif

}