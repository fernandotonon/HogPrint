/*
 * Project name:
     PortExpander (Demonstration of the Port Expander library routines)
 * Copyright:
     (c) Mikroelektronika, 2009.
 * Revision History:
     20090505:
       - initial release;
       - 20090720 - modified by Slavisa Zlatanovic;
 * Description:
     This project is simple demonstration how to use Port Expander Library functions.
 * Test configuration:
     MCU:             PIC16F887
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41291F.pdf
     Dev.Board:       EasyPIC6 - ac:PortExpander
                      http://www.mikroe.com/eng/products/view/297/easypic6-development-system/
     Oscillator:      HS, 8.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on Port Expander switches SW6.1, SW6.2, SW6.3, SW6.4 and SW6.5.
     - Turn on PORT0 and PORT1 LEDs (SW6.8).
     - Port Expander's PORTA = PORT0 on the EasyPIC6 dev. board.
     - Port Expander's PORTB = PORT1 on the EasyPIC6 dev. board.
 */

// Port Expander module connections
sbit  SPExpanderCS  at RA2_bit;
sbit  SPExpanderRST at RA3_bit;
sbit  SPExpanderCS_Direction  at TRISA2_bit;
sbit  SPExpanderRST_Direction at TRISA3_bit;
// End Port Expander module connections

unsigned char i = 0;

#define Output_PORT0                             // Comment / uncomment the apropriate line to
//#define Output_PORT1                           // get output on the wanted port PO or P1

void main() {

  ANSEL  = 0;                                    // Configure AN pins as digital I/O
  ANSELH = 0;
  C1ON_bit = 0;                                  // Disable comparators
  C2ON_bit = 0;
  TRISB = 0;
  
#ifdef Output_PORT0
// Port Expander Library uses SPI1 module
  SPI1_Init();                                   // Initialize SPI module used with PortExpander

  Expander_Init(0);                              // Initialize Port Expander

  Expander_Set_DirectionPortA(0, 0x00);          // Set Expander's PORTA to be output

  Expander_Set_DirectionPortB(0,0xFF);           // Set Expander's PORTB to be input
  Expander_Set_PullUpsPortB(0,0xFF);             // Set pull-ups to all of the Expander's PORTB pins

  while(1) {                                     // Endless loop
    Expander_Write_PortA(0, i++);                // Write i to expander's PORTA
    PORTB = Expander_Read_PortB(0);              // Read expander's PORTB and write it to LEDs
    Delay_ms(100);
  }
#endif

#ifdef Output_PORT1
// Port Expander Library uses SPI1 module
  SPI1_Init();                                   // Initialize SPI module used with PortExpander

  Expander_Init(0);                              // Initialize Port Expander

  Expander_Set_DirectionPortB(0, 0x00);          // Set Expander's PORTB to be output

  Expander_Set_DirectionPortA(0,0xFF);           // Set Expander's PORTA to be input
  Expander_Set_PullUpsPortA(0,0xFF);             // Set pull-ups to all of the Expander's PORTA pins

  while(1) {                                     // Endless loop
    Expander_Write_PortB(0, i++);                // Write i to expander's PORTB
    PORTB = Expander_Read_PortA(0);              // Read expander's PORTA and write it to LEDs
    Delay_ms(100);
  }
#endif

}