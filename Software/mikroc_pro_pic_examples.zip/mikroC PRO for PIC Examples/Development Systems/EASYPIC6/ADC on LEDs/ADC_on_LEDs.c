/*
 * Project name:
     ADC_on LEDs (Display the result of ADC on LEDs)
 * Copyright:
     (c) Mikroelektronika, 2009.
 * Revision History:
     20080930:
       - initial release;
       - 20090720 - modified by Slavisa Zlatanovic;
 * Description:
      A simple example of using the ADC library.
      ADC results are displayed on PORTC and PORTD.
 * Test configuration:
     MCU:             PIC16F887
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41291F.pdf
     Dev.Board:       EasyPIC6 - ac:ADC
                      http://www.mikroe.com/eng/products/view/297/easypic6-development-system/
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn on PORTC and PORTD LEDs.
     - To simulate analog input on ADC channel 2, use on-board potentiometer P1
       by connecting jumper J15 to MCU pin corresponding to ADC channel 2 input.
 */

unsigned int temp_res;

void main() {
  ANSEL  = 0x04;              // Configure AN2 pin as analog
  ANSELH = 0;                 // Configure other AN pins as digital I/O
  C1ON_bit = 0;               // Disable comparators
  C2ON_bit = 0;
  
  TRISA  = 0xFF;              // PORTA is input
  TRISC  = 0;                 // PORTC is output
  TRISD  = 0;                 // PORTD is output

  do {
    temp_res = ADC_Read(2);   // Get 10-bit results of AD conversion
    PORTD = temp_res;         // Send lower 8 bits to PORTD
    PORTC = temp_res >> 8;    // Send 2 most significant bits to RC1, RC0
  } while(1);
}