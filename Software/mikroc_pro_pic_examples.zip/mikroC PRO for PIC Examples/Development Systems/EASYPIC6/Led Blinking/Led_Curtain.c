/*
 * Project name:
     LED_Curtain (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2009.
 * Revision History:
     20080930:
       - initial release;
       - 20090720 - modified by Slavisa Zlatanovic;
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     PORTB, PORTC and PORTD.
 * Test configuration:
     MCU:             PIC16F887
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41291F.pdf
     Dev.Board:       EasyPIC6 - ac:LEDs
                      http://www.mikroe.com/eng/products/view/297/easypic6-development-system/
     Oscillator:      HS, 08.0000 MHz
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:
     - Turn ON the PORT LEDs at SW9.
*/

char counter;

void wait() {
  Delay_ms(100);
}

void main() {

  ANSEL  = 0;                                    // Configure AN pins as digital
  ANSELH = 0;
  C1ON_bit = 0;                                  // Disable comparators
  C2ON_bit = 0;
  
  TRISA = 0x00;                                  // set direction to be output
  TRISB = 0x00;                                  // set direction to be output
  TRISC = 0x00;                                  // set direction to be output
  TRISD = 0x00;                                  // set direction to be output

  PORTA = 0x00;                                  // turn OFF the PORTD leds
  PORTB = 0x00;                                  // turn OFF the PORTD leds
  PORTC = 0x00;                                  // turn OFF the PORTC leds
  PORTD = 0x00;                                  // turn OFF the PORTD leds
  while (1) {
    for (counter = 0; counter < 8; counter++){
      PORTA |= 1 << counter;
      PORTB |= 1 << counter;
      PORTC |= 1 << counter;
      PORTD |= 1 << counter;
 
      wait();
    }
       
    counter = 0;
    while (counter < 8) {
      PORTA &= ~(1 << counter);
      PORTB &= ~(1 << counter);
      PORTC &= ~(1 << counter);
      PORTD &= ~(1 << counter);
      wait();
      counter++;
    }
  }
}