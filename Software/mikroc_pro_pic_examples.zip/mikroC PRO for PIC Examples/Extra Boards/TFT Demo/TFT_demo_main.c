/*
 * Project name:
     TFT_Demo
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     20101210:
       - initial release;
 * Description:
     This is a simple TFT display demo example.
 * Test configuration:
     MCU:             PIC18F87J50
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39775c.pdf
     Dev.Board:       mikroMMB for PIC18FJ board  ac:MMB
                      http://www.mikroe.com/eng/products/view/585/mikrommb-for-pic18fj-board/
     Oscillator:      HS-PLL, 8.000 MHz Crystal, 48.000 MHz MCU Clock
     Ext. Modules:    -
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:

*/

#include "TFT_demo_objects.h"

void main() {

  Start_TP();

  while (1) {
    Check_TP();

  }

}